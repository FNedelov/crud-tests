﻿using DependencyInjection.Interfaces;

namespace DependencyInjection.PlaneFigures
{
    internal class Rectangle : IPlaneFigure
    {
        private readonly float _a;
        private readonly float _b;

        public Rectangle(float a, float b)
        {
            _a = a;
            _b = b;
        }
        public string Area()
        {
            return $"The area of {GetType().Name} is: {_a * _b}";
        }

        public string Circumference()
        {
            return $"The circumference of {GetType().Name} is: {2 * (_a + _b)}";
        }
    }
}
