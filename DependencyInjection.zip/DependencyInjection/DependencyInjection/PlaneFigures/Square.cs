﻿using DependencyInjection.Interfaces;

namespace DependencyInjection.PlaneFigures
{
    internal class Square : IPlaneFigure
    {
        private readonly float _a;

        public Square(float a)
        {
            _a = a;
        }
        public string Area()
        {
            return $"The area of {GetType().Name} is: {_a * _a}";
        }

        public string Circumference()
        {
            return $"The circumference of {GetType().Name} is: {4 * _a}";
        }
    }
}