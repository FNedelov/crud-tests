﻿using DependencyInjection.Interfaces;

namespace DependencyInjection.PlaneFigures
{
    internal class Circle : IPlaneFigure
    {
        private readonly float _radius;

        public Circle(float radius)
        {
            _radius = radius;
        }
        public string Area()
        {
            return $"The area of {GetType().Name} is: {_radius * _radius * (float)Math.PI}";
        }

        public string Circumference()
        {
            return $"The circumference of {GetType().Name} is: {2 * _radius * (float)Math.PI}";
        }
    }
}