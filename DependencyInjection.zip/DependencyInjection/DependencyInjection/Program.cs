﻿using DependencyInjection.Classes;
using DependencyInjection.PlaneFigures;

internal class Program
{
    private static void Main(string[] args)
    {
        Circle circle = new(12.8f);
        Rectangle rectangle = new(4f, 7f);
        Square square = new(4.9f);


        GeometryCalculator calculator1 = new(circle);
        GeometryCalculator calculator2 = new(rectangle);
        GeometryCalculator calculator3 = new(square);


        Console.WriteLine(calculator1.GetPlaneFigureAreaAndCircumference());
        Console.WriteLine(calculator2.GetPlaneFigureAreaAndCircumference());
        Console.WriteLine(calculator3.GetPlaneFigureAreaAndCircumference());

        Console.ReadLine();
    }
}