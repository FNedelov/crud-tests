﻿using DependencyInjection.Interfaces;

namespace DependencyInjection.Classes
{
    internal class GeometryCalculator
    {
        private readonly IPlaneFigure _planeFigure;

        public GeometryCalculator(IPlaneFigure planeFigure)
        {
            _planeFigure = planeFigure;   
        }

        public string GetPlaneFigureAreaAndCircumference()
        {
            string areaResultText = _planeFigure.Area();
            string circumferenceResultText = _planeFigure.Circumference();

            return $"{areaResultText} - {circumferenceResultText}";
        }
    }
}