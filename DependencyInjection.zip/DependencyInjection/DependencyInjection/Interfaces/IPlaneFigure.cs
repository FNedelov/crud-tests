﻿namespace DependencyInjection.Interfaces
{
    internal interface IPlaneFigure
    {
        string Area();
        string Circumference();
    }
}
